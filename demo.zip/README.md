# README #

This is the Anchor demo Magento store to be used for Fleet - a continuous delivery system for Magento.

### What is this repository for? ###

* Download 
* Version 1.0.0
* [Learn Markdown](http://www.anchor.com.au/hosting/support/ContinuousDeliveryForMagentoWithFleet)

### How do I get set up? ###

* [Learn how here](http://www.anchor.com.au/hosting/support/ContinuousDeliveryForMagentoWithFleet)

### Contribution guidelines ###

* N/A

### Who do I talk to? ###

* Anchorites @ www.anchor.com.au/contact-us